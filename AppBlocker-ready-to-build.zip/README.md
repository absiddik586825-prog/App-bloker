# App Blocker

A simple Android app blocker using AccessibilityService. Works without root.

**Target:** Android 8.0+ (API 26), including Android 15 / TECNO devices.

## Features

- List installed launcher apps and select which ones to block
- AccessibilityService detects when a blocked app comes to the foreground
- Full-screen PIN lock screen (default PIN: `1234`)
- Correct PIN allows the app for 1 minute, then re-blocks
- Change PIN from the main screen

## Build in Android Studio

1. Open this folder in Android Studio (File → Open).
2. Let Gradle sync (Android Studio will download the Gradle wrapper if needed).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Install the APK on the device.

### Command-line build (optional)

```bash
# First time: generate wrapper if missing
gradle wrapper --gradle-version 8.9

./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Setup on phone

1. Open **App Blocker**.
2. (Recommended) Change the default PIN (1234).
3. Tap **Enable Accessibility Service** → find **App Blocker** → turn it **ON**.
4. Confirm the system disclosure dialog.
5. Back in the app, check the apps you want to block.

## Notes for Android 15 / TECNO

- Accessibility services require explicit user consent; the system may show an extra disclosure page.
- Some TECNO/HiOS skins add extra “permission” or “auto-start” restrictions. If the service stops working after reboot, open Settings → Apps → App Blocker → enable Auto-start / Battery unrestricted.
- This app does **not** use Device Admin / Device Owner. For stronger enterprise locking, use DevicePolicyManager with device-owner provisioning.
- Package visibility is handled via the standard `<queries>` intent for `MAIN`/`LAUNCHER` (no `QUERY_ALL_PACKAGES` needed).

## Security limitations

- A determined user can disable the accessibility service or force-stop the app.
- Temporary allow is intentionally short (1 minute).
- Not a substitute for parental-control / MDM solutions on managed devices.
