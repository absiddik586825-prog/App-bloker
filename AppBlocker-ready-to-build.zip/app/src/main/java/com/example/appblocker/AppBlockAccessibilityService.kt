package com.example.appblocker

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppBlockAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        // Ignore system UI / launcher packages that commonly appear
        if (pkg.startsWith("com.android.systemui") ||
            pkg == "com.android.launcher" ||
            pkg == "com.google.android.apps.nexuslauncher" ||
            pkg.contains("launcher", ignoreCase = true) && pkg.contains("android", ignoreCase = true)
        ) {
            // Still allow blocking if user explicitly selected a launcher, but avoid loops for common ones
            // Fall through only if user marked it blocked
        }

        val prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE)
        if (!prefs.getBoolean(MainActivity.blockedKey(pkg), false)) return

        // Respect temporary allow window after successful PIN
        val until = prefs.getLong(MainActivity.tempAllowKey(pkg), 0L)
        if (until > System.currentTimeMillis()) return

        val i = Intent(this, BlockScreenActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )
            putExtra(BlockScreenActivity.EXTRA_BLOCKED_PACKAGE, pkg)
        }
        startActivity(i)
    }

    override fun onInterrupt() {
        // Required override
    }
}
