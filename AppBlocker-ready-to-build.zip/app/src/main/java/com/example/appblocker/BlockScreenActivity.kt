package com.example.appblocker

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class BlockScreenActivity : AppCompatActivity() {

    private var blockedPackage: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on and try to stay on top
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        )

        blockedPackage = intent.getStringExtra(EXTRA_BLOCKED_PACKAGE)
        val prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(0xFF000000.toInt())
        }

        val title = TextView(this).apply {
            text = "Application Blocked"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        val info = TextView(this).apply {
            text = "This application is currently blocked.\nEnter PIN to allow for 1 minute."
            textSize = 16f
            setTextColor(0xFFCCCCCC.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 32)
        }

        val pinInput = EditText(this).apply {
            hint = "Enter PIN"
            setHintTextColor(0xFF888888.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFF222222.toInt())
        }

        val unlock = Button(this).apply {
            text = "Allow for 1 minute"
            setOnClickListener {
                val entered = pinInput.text.toString()
                val stored = prefs.getString(MainActivity.KEY_PIN, MainActivity.DEFAULT_PIN) ?: MainActivity.DEFAULT_PIN
                if (entered == stored) {
                    val pkg = blockedPackage
                    if (pkg != null) {
                        // Temporary allow so the accessibility service does not immediately re-block
                        val until = System.currentTimeMillis() + MainActivity.TEMP_ALLOW_DURATION_MS
                        prefs.edit()
                            .putLong(MainActivity.tempAllowKey(pkg), until)
                            .apply()
                    }
                    // Go home so the blocked app is not left in foreground
                    val home = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
                        addCategory(android.content.Intent.CATEGORY_HOME)
                        flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    startActivity(home)
                    finish()
                } else {
                    Toast.makeText(this@BlockScreenActivity, "Incorrect PIN", Toast.LENGTH_SHORT).show()
                    pinInput.text.clear()
                }
            }
        }

        box.addView(title)
        box.addView(info)
        box.addView(pinInput)
        box.addView(unlock)
        setContentView(box)

        // Disable back button / gesture exit
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Swallow back — user must enter PIN or leave via Home
            }
        })
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Block volume keys from being used as a workaround on some devices
        if (keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.onKeyDown(keyCode, event)
    }

    companion object {
        const val EXTRA_BLOCKED_PACKAGE = "blocked_package"
    }
}
