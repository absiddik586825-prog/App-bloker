package com.example.appblocker

import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var list: LinearLayout
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        if (!prefs.contains(KEY_PIN)) {
            prefs.edit().putString(KEY_PIN, DEFAULT_PIN).apply()
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }

        val title = TextView(this).apply {
            text = "App Blocker"
            textSize = 28f
            setPadding(0, 0, 0, 16)
        }
        root.addView(title)

        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, 0, 0, 24)
        }
        root.addView(statusText)

        val pinBtn = Button(this).apply {
            text = "Change PIN"
            setOnClickListener { changePin() }
        }
        root.addView(pinBtn)

        val accessBtn = Button(this).apply {
            text = "Enable Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(accessBtn)

        val hint = TextView(this).apply {
            text = "Select apps to block. After enabling the accessibility service, opening a blocked app will show a PIN screen."
            textSize = 13f
            setPadding(0, 24, 0, 16)
        }
        root.addView(hint)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = ScrollView(this).apply {
            addView(list)
        }
        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        setContentView(root)
        loadApps()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val enabled = isAccessibilityServiceEnabled()
        statusText.text = if (enabled) {
            "Accessibility Service: ON"
        } else {
            "Accessibility Service: OFF — tap the button below and enable \"App Blocker\""
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${AppBlockAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun loadApps() {
        list.removeAllViews()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        for (ri in apps) {
            val pkg = ri.activityInfo.packageName
            if (pkg == packageName) continue

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 8, 0, 8)
            }

            val cb = CheckBox(this).apply {
                text = ri.loadLabel(pm).toString()
                isChecked = prefs.getBoolean(blockedKey(pkg), false)
                setOnCheckedChangeListener { _, checked ->
                    prefs.edit().putBoolean(blockedKey(pkg), checked).apply()
                }
            }
            row.addView(cb)
            list.addView(row)
        }
    }

    private fun changePin() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "New PIN (min 4 digits)"
        }
        AlertDialog.Builder(this)
            .setTitle("Set PIN")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val p = input.text.toString().trim()
                if (p.length >= 4) {
                    prefs.edit().putString(KEY_PIN, p).apply()
                    Toast.makeText(this, "PIN saved", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "PIN must be at least 4 digits", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    companion object {
        const val PREFS_NAME = "blocker"
        const val KEY_PIN = "pin"
        const val DEFAULT_PIN = "1234"
        const val TEMP_ALLOW_PREFIX = "temp_allow_"
        const val TEMP_ALLOW_DURATION_MS = 60_000L // 1 minute temporary allow

        fun blockedKey(pkg: String) = "blocked_$pkg"
        fun tempAllowKey(pkg: String) = "$TEMP_ALLOW_PREFIX$pkg"
    }
}
