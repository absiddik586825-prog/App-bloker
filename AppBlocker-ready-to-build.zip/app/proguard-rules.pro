# Keep accessibility service
-keep class com.example.appblocker.AppBlockAccessibilityService { *; }
