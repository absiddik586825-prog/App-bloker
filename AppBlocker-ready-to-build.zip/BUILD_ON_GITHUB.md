# Build the APK with GitHub Actions

1. Upload this project to a GitHub repository.
2. Open the **Actions** tab.
3. Select **Build Android APK**.
4. Choose **Run workflow**.
5. When the workflow finishes, open the run and download the `AppBlocker-debug-apk` artifact.
6. Install `app-debug.apk` on the Android phone.

The project uses Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, minSdk 26, and targetSdk 35.
